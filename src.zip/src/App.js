import logo from './logo.svg';
import './App.css';
import React from 'react';
import {BrowserRouter,Link,Route,Routes} from 'react-router-dom'
import Categories from './Component/categories';
import Products from './Component/products';
import Basket from './Component/basket';
import Footer from './Component/footer';
import Header from './Component/header';
import Categorie from './Component/categories';
import Product from './Component/products';
function App() {
  return (
    <>
     {/* <App/> */}
    </>
  );
}

export default App;
